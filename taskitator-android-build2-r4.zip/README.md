# Taskitator Android — Milestone 1 recovery source (unverified)

**Application ID:** `com.mazendev.taskitator`  
**Clerk:** existing production Taskitator instance, email/password and Google configured in Clerk Dashboard  
**Worker:** `https://taskitator-sync.spacexmzez.workers.dev`

This is the repaired Android **source project**, not a compiled or tested release.
No production Worker or GitHub changes have been deployed.

**Start with `START_HERE.md`**, then run `build-debug.ps1` on a Windows PC with Android Studio and JDK 21 installed.

Native Clerk login may receive 401 from the existing Worker until the server-side `azp` compatibility issue is safely resolved. The proposed Worker change is in `MANUAL_WORKER_AUTH.md`; do not deploy it without checking real native JWT claims and regression testing.

Do not use your primary Taskitator account for initial tests. Use a disposable account with no valuable tasks.
