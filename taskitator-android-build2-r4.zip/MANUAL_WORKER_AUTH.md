# Production Worker native Clerk JWT compatibility — review before deployment

**Do not deploy this automatically.** The Android code uses the existing production Clerk publishable key and Worker URL. The Worker `verifySession` function currently requires `origins.includes(claims.azp)` and additionally checks `(origin && origin !== claims.azp)`.

A native Android session request normally has no HTTP `Origin` header, and its Clerk JWT authorized-party (`azp`) claim may be absent or different from the website. That can produce HTTP 401 even for a valid Clerk session.

## Proposed narrow change

In `worker.js` inside `verifySession`, immediately after:

```js
const now = Math.floor(Date.now() / 1000), origins = allowedOrigins(env);
const origin = request.headers.get('Origin');
```

add:

```js
// Browser sessions remain restricted to the configured website origin.
// Native SDK calls have no Origin header. Accept only the explicitly
// supported native authorized-party form, or a missing azp claim.
// All JWT signature, issuer, expiry, Clerk session status and user checks
// below remain mandatory.
const webParty = typeof claims.azp === 'string' && origins.includes(claims.azp)
    && (!origin || origin === claims.azp);
const nativeParty = !origin && (claims.azp == null || claims.azp === 'com.mazendev.taskitator');
const validParty = webParty || nativeParty;
```

Then replace:

```js
!origins.includes(claims.azp) || (origin && origin !== claims.azp) ||
```

with:

```js
!validParty ||
```

**Before deployment:** inspect the actual Android Clerk session JWT claims locally (decode payload only, never share the token), verify whether `azp` is absent or equals the Android package identifier. If Clerk uses a different native authorized-party format, adjust the allowlist only after confirming the SDK's documented format. Do not relax `Origin` checking for browser requests or disable signature, issuer, session, expiry or account-owner verification.

The existing Worker has `ALLOWED_ORIGINS=https://taskitator.mazendev.com` and `CLERK_ISSUER=https://clerk.mazendev.com`. Keep these. No additional secret is needed for native auth.

## Regression tests required

1. Website Clerk session from allowed origin: accepted.
2. Website request from disallowed origin: 403.
3. Valid native Clerk session without Origin: accepted.
4. Forged/expired/revoked Clerk JWT: rejected.
5. Native session for user A cannot access user B's account.
6. Existing Google/email sign-in website behavior unchanged.

This document is a proposed Worker patch, **not** evidence that native auth is functioning on production.
