# Taskitator Android — Milestone 1 recovery source (UNVERIFIED BUILD)

**Source:** AI Studio archive `taskitator-nov-4-2026-10-46-16-am-2.zip`.

**Application ID:** `com.mazendev.taskitator`.

**Status:** Source-code repair package, **not** a release and **not** a confirmed Milestone 1 pass. No APK was compiled from this source because this environment lacks Android SDK, Gradle and external dependency access. Do not distribute or rely on sync until device and Worker integration tests pass.

## Changes

- Native Clerk Android UI for email/password and Google sign-in, using the existing Taskitator production Clerk instance. Manual JWT pasting removed. Clerk manages session lifecycle; app requests a fresh session token for Worker operations.
- Removed persisted bearer tokens and disabled Android Auto Backup of app data.
- Isolated account caches by Worker-verified identity; anonymous cache is separate.
- Fixed Android package ID and removed release signing with a debug keystore.
- Introduced conservative three-way merge for task fields, safe settings and saved criteria; server-owned and unknown fields are never silently overwritten.
- Added durable frozen upload payload with mutation ID to retry uncertain pushes; initial cloud pull precedes first upload; unchanged snapshots are not pushed.
- Added account-change epoch checks, atomic snapshot/base/pending writes, conflict backups, and unit tests for merge behavior.
- Blocked fake local Emergency Bypass and AI audit approval. Those require server-owned Milestone 3/4 implementations.

## Critical blocker: production Worker native JWT compatibility

The production Worker currently checks `claims.azp` against website `ALLOWED_ORIGINS`. Native Android Clerk session JWTs may not contain the website authorized-party claim. See `MANUAL_WORKER_AUTH.md` for the proposed minimal, review-required change. **No Worker deployment was performed.** Until tested and deployed, native login may show Worker 401 even when Clerk login succeeds.

## Build debug APK on Windows (Android Studio)

1. Install Android Studio with Android SDK Platform 36, SDK Build Tools and JDK 21.
2. Extract this ZIP to a new folder. The Gradle wrapper binary is **not included** in the AI Studio source archive. Copy the existing wrapper from the `app` branch of `spacexmzez-bit/Taskitator`, folder `android/`: `gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar` into the corresponding locations in this extracted project. The wrapper properties are already included here (Gradle 9.8.2).
3. Open the extracted project root in Android Studio. Allow Gradle to download dependencies and sync. If the chosen AGP/Kotlin/Clerk versions conflict, preserve the full Gradle error log; this environment could not validate dependency compatibility.
4. Run `gradlew.bat testDebugUnitTest` in the Android Studio terminal.
5. Run `gradlew.bat assembleDebug`.
6. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`. Copy to your Android device, enable installation of local APKs when prompted, and install.
7. Test Clerk email/password and Google sign-in; verify `/auth/me`, `/sync/pull` and `/sync/push` against a disposable Taskitator account. Do not test first on an account with irreplaceable data.

## Must-pass device tests

- Sign in/out, restore Clerk session, switch between two Clerk users; verify no cross-account data.
- Fresh install with populated web account: first pull without blank push.
- Offline task edit survives force-close and reconnect.
- Two devices edit different fields on same task: preserve both.
- Same-field conflict: dialog and backup, never silent overwrite.
- Delete-vs-edit and server-owned-field conflict: no automatic destructive push.
- Simulate uncertain push and retry with identical mutation ID and payload.
- Check Smart/Study recurrence, Dynamic Priority, Universe, Sleep Lock, breaks and audit ledger are unchanged after Android edits.
- Ensure Worker rejects unauthorized tokens and respects all server protections.

## Scope

Milestone 1 foundation only. Milestone 2 task features and Milestones 3–5 Pro/AI/release work are **not** claimed complete.
