package com.example

import android.app.Application
import com.clerk.api.Clerk

class TaskitatorApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Public identifier, not a secret. Matches the existing Taskitator production Clerk instance.
        Clerk.initialize(this, "pk_live_Y2xlcmsubWF6ZW5kZXYuY29tJA")
    }
}
