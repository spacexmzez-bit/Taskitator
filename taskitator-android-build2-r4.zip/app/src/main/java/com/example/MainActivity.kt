package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.clerk.api.Clerk
import com.clerk.ui.auth.AuthView
import com.example.data.model.AuthState
import com.example.ui.MainApp
import com.example.ui.theme.TaskitatorTheme
import com.example.ui.viewmodel.TaskitatorViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TaskitatorTheme {
                val vm: TaskitatorViewModel = viewModel()
                val initialized by Clerk.isInitialized.collectAsState()
                val clerkUser by Clerk.userFlow.collectAsState()
                val flowComplete by Clerk.isAuthFlowCompleteFlow.collectAsState()
                val auth by vm.authState.collectAsState()
                val scope = rememberCoroutineScope()
                LaunchedEffect(initialized, clerkUser?.id, flowComplete) {
                    if (initialized && flowComplete && clerkUser != null) vm.onClerkAuthenticated(clerkUser!!.id)
                    else if (initialized && clerkUser == null) vm.onClerkSignedOut()
                }
                when {
                    !initialized -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    clerkUser == null || !flowComplete -> AuthView(isDismissible = false)
                    auth is AuthState.Authenticated -> MainApp(vm)
                    auth is AuthState.Unlinked -> AccountConnectionScreen(
                        "Your Clerk login is active, but no Taskitator cloud account is connected.",
                        onRetry = { vm.connectWorkerAccount() },
                        onSignOut = { scope.launch { vm.signOut() } },
                        retryLabel = "Create Taskitator account"
                    )
                    auth is AuthState.Connecting || auth is AuthState.SignedOut -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    else -> AccountConnectionScreen(
                        when (auth) {
                            is AuthState.SessionExpired -> (auth as AuthState.SessionExpired).message
                            is AuthState.AccountDeleted -> (auth as AuthState.AccountDeleted).message
                            is AuthState.Error -> (auth as AuthState.Error).message
                            else -> "Unable to connect to Taskitator."
                        },
                        onRetry = { vm.onClerkAuthenticated(clerkUser!!.id) },
                        onSignOut = { scope.launch { vm.signOut() } },
                        retryLabel = "Retry connection"
                    )
                }
            }
        }
    }
}

@Composable
private fun AccountConnectionScreen(message: String, onRetry: () -> Unit, onSignOut: () -> Unit, retryLabel: String) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Taskitator", style = MaterialTheme.typography.headlineMedium)
        Text(message)
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text(retryLabel) }
        OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) { Text("Sign out") }
    }
}
