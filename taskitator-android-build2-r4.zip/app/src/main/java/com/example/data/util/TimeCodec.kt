package com.example.data.util

import org.json.JSONObject
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/**
 * The website stores created_at / completed_at as ISO-8601 strings (new Date().toISOString()).
 * Android models them as epoch millis. This codec reads both forms and always writes the website's form,
 * because the website calls string methods on these fields (split / localeCompare) and fails on numbers.
 */
object TimeCodec {
    private val iso = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneOffset.UTC)

    fun toIso(ms: Long): String = iso.format(Instant.ofEpochMilli(ms))

    fun parse(v: Any?): Long? = when (v) {
        null, JSONObject.NULL -> null
        is Number -> v.toLong().takeIf { it > 0 }
        is String -> {
            val s = v.trim()
            if (s.isEmpty()) null
            else s.toLongOrNull()?.takeIf { it > 0 }
                ?: runCatching { Instant.parse(s).toEpochMilli() }.getOrNull()
                ?: runCatching { OffsetDateTime.parse(s).toInstant().toEpochMilli() }.getOrNull()
        }
        else -> null
    }

    /** UTC calendar date (yyyy-MM-dd) of a timestamp, the same value the website gets from iso.split('T')[0]. */
    fun utcDate(ms: Long): String = toIso(ms).substring(0, 10)
}
