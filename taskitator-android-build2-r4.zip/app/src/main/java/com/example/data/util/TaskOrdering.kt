package com.example.data.util

import com.example.data.model.CustomPriority
import com.example.data.model.Task
import com.example.data.model.TaskStatus

enum class SortMode(val wire: String, val label: String) {
    PRIORITY("priority", "Priority"),
    ALPHA("alpha", "Alphabetical"),
    REQUIRED("required", "Required, then priority");

    companion object {
        fun fromWire(s: String?): SortMode = values().firstOrNull { it.wire == s } ?: PRIORITY
    }
}

/** Ports of the website's sort comparator (app.js) and Dynamic Priority (components.js effectiveMap). */
object TaskOrdering {
    private const val TARGET_KEY = "dynamic_priority_target"

    /**
     * Effective priority is derived from the tree and never stored: a task with a dynamic_priority_target
     * uses that priority while only bonus work remains (no unfinished non-bonus descendant, at least one
     * unfinished bonus descendant; trashed tasks ignored).
     */
    fun effectivePriorities(tasks: List<Task>, priorities: List<CustomPriority>): Map<String, String> {
        val out = HashMap<String, String>()
        val valid = priorities.map { it.id }.toSet()
        val byParent: Map<String, List<Task>> by lazy {
            tasks.filter { it.parentId != null }.groupBy { it.parentId!! }
        }
        for (t in tasks) {
            val target = t.unmappedFields[TARGET_KEY] as? String
            if (target.isNullOrEmpty() || t.status != TaskStatus.ACTIVE || target == t.priorityId) continue
            if (valid.isNotEmpty() && target !in valid) continue
            var required = false
            var bonus = false
            val seen = mutableSetOf(t.id)
            val stack = ArrayDeque(byParent[t.id].orEmpty())
            while (stack.isNotEmpty() && !required) {
                val c = stack.removeLast()
                if (!seen.add(c.id) || c.status == TaskStatus.TRASH) continue
                if (c.status != TaskStatus.COMPLETED) { if (c.isBonus) bonus = true else required = true }
                byParent[c.id]?.let { stack.addAll(it) }
            }
            if (!required && bonus) out[t.id] = target
        }
        return out
    }

    /** Natural, case-insensitive ordering like localeCompare(..., {numeric:true, sensitivity:'base'}). */
    private val natural = Comparator<String> { a, b ->
        val x = a.lowercase(); val y = b.lowercase()
        var i = 0; var j = 0
        while (i < x.length && j < y.length) {
            if (x[i].isDigit() && y[j].isDigit()) {
                var ei = i; while (ei < x.length && x[ei].isDigit()) ei++
                var ej = j; while (ej < y.length && y[ej].isDigit()) ej++
                val nx = x.substring(i, ei).trimStart('0'); val ny = y.substring(j, ej).trimStart('0')
                if (nx.length != ny.length) return@Comparator nx.length - ny.length
                val c = nx.compareTo(ny)
                if (c != 0) return@Comparator c
                i = ei; j = ej
            } else {
                if (x[i] != y[j]) return@Comparator x[i].compareTo(y[j])
                i++; j++
            }
        }
        (x.length - i) - (y.length - j)
    }

    fun sort(tasks: List<Task>, mode: SortMode, priorities: List<CustomPriority>, effective: Map<String, String>): List<Task> {
        val rank = priorities.associate { it.id to it.rank }
        fun rankOf(t: Task) = rank[effective[t.id] ?: t.priorityId] ?: 9999
        fun due(t: Task) = t.dueDate.ifBlank { "9999-99-99" }
        val cmp = Comparator<Task> { a, b ->
            if (mode == SortMode.ALPHA) return@Comparator natural.compare(a.title, b.title)
            if (mode == SortMode.REQUIRED && a.isBonus != b.isBonus) return@Comparator if (a.isBonus) 1 else -1
            val r = rankOf(a) - rankOf(b)
            if (r != 0) return@Comparator r
            val d = due(a).compareTo(due(b))
            if (d != 0) return@Comparator d
            a.createdAt.compareTo(b.createdAt)
        }
        return tasks.sortedWith(cmp) // stable, like the website's Array.sort
    }
}
