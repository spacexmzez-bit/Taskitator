package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Task
import com.example.data.model.TaskStatus
import com.example.data.util.TimeCodec
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen

/** Website "Completed Tasks" modal: Today view lists today's completions, General lists all of them. */
@Composable
fun CompletedTasksDialog(
    tasks: List<Task>,
    currentScreen: AppScreen,
    todayDate: String,
    onUncomplete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val todayOnly = currentScreen == AppScreen.TODAY
    val list = tasks.filter { t ->
        if (t.status != TaskStatus.COMPLETED) return@filter false
        if (!todayOnly) return@filter true
        val due = t.dueDate.trim().lowercase()
        val done = t.completedAt?.let { TimeCodec.utcDate(it) } ?: ""
        due == "today" || due == todayDate || done == todayDate
    }.sortedByDescending { it.completedAt ?: 0L }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
            modifier = Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.8f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (todayOnly) "✓ Today's Completed Tasks" else "✓ Workspace Completed Tasks",
                        style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss) { Text("Close", color = TextSecondary) }
                }
                Spacer(Modifier.height(8.dp))
                if (list.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No completed tasks found.", color = TextMuted, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(list, key = { it.id }) { t ->
                            Surface(shape = RoundedCornerShape(10.dp), color = DarkSurfaceVariant, modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(t.resolvedTitle.ifBlank { t.title }, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                        val badges = listOfNotNull(
                                            if (t.isBonus) "⭐ Bonus" else null,
                                            if (t.aiLocked) "🔒 AI" else null,
                                            if (t.requireAllSubtasksFirst) "🛡 Shielded" else null
                                        )
                                        if (badges.isNotEmpty()) Text(badges.joinToString("  "), color = TextSecondary, fontSize = 11.sp)
                                    }
                                    if (t.aiLocked) {
                                        Text("🔒", fontSize = 16.sp) // permanent: the server rejects un-completing AI-verified tasks
                                    } else {
                                        TextButton(onClick = { onUncomplete(t.id) }) { Text("Undo", color = ElectricBlue, fontSize = 12.sp) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
